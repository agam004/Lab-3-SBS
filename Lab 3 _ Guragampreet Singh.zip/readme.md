# Lab 3 (Python)

## Key Syntax observations:
    - The code looks kind of incomplete as other languages like : JAVA, JavaScript, C#, etc. Have proper brackets, semicolons.
    - Some differences in writing "if" "else" : "else if" is here "elif".
    - And was getting confused to write the loop, first tried for loop but then end up using while.
    - and while using if we usally used "||" for or but in python we cant but in commmand with a specificed array works.